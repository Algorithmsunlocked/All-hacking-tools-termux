cd
cd
cd AllHackingTools
cd Tool
cp msdc /data/data/com.termux/files/usr/bin/
cp msdconsole /data/data/com.termux/files/usr/bin/
cp msdconsoleUPD /data/data/com.termux/files/usr/bin/
cp msdServer /data/data/com.termux/files/usr/bin/
cp msd /data/data/com.termux/files/usr/bin/
cp ms /data/data/com.termux/files/usr/bin/
cp m /data/data/com.termux/files/usr/bin/
cp sys /data/data/com.termux/files/usr/bin/
cp system /data/data/com.termux/files/usr/bin/
cp View-deleted-activity /data/data/com.termux/files/usr/bin/
cp theme /data/data/com.termux/files/usr/bin/
cp Theme /data/data/com.termux/files/usr/bin/
cd
cd
cd /data/data/com.termux/files/usr/bin/
chmod +x msdconsole
chmod +x msdconsoleUPD
chmod +x msdc
chmod +x msdServer
chmod +x msd
chmod +x ms
chmod +x m
chmod +x sys
chmod +x system
chmod +x View-deleted-activity
chmod +x theme
chmod +x Theme
ls
sleep 0.2
clear
cd 
cd 
