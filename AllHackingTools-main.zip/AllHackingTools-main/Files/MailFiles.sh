apt-get install git
apt-get install python
apt-get install tsu
cd
cd AllHackingTools
git clone https://github.com/d4az/hack-gmail.git
cd
cd AllHackingTools
git clone https://github.com/4w4k3/KnockMail.git
cd KnockMail
pip install -r requeriments.txt
cd 
cd AllHackingTools 
cd Files
cd 
cd AllHackingTools
git clone https://github.com/thewhiteh4t/pwnedOrNot.git
cd pwnedOrNot
cd
cd
cd AllHackingTools
git clone https://github.com/Curioo/emailpyspam.git
cd emailpyspam
cd
cd
cd AllHackingTools
git clone https://github.com/mishakorzik/Gmail-Hack
cd Gmail-Hack
bash install.sh
cd
cd
cd AllHackingTools
git clone https://github.com/mishakorzik/Email-Spammer
cd
cd
cd AllHackingTools
