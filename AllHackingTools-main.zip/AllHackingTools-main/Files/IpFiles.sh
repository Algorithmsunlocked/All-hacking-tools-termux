cd
cd AllHackingTools
git clone https://github.com/UndeadSec/EvilURL.git
cd EvilURL
cd
cd AllHackingTools
git clone https://github.com/ciku370/OSIF
cd OSIF
pip2 install -r requirements.txt
cd
cd
cd AllHackingTools
git clone https://github.com/Cvar1984/Easymap
cd Easymap
bash install.sh
cd
cd
cd AllHackingTools
git clone https://github.com/Gameye98/AstraNmap
cd
cd 
cd AllHackingTools
git clone https://github.com/evait-security/weeman
cd
cd
cd AllHackingTools
git clone https://github.com/exlinee/MaxSubdoFinder
cd
cd
cd AllHackingTools
git clone https://github.com/jofpin/trape.git
cd trape
python2 -m pip install -r requirements.txt
cd
cd
cd AllHackingTools
git clone https://github.com/Tuhinshubhra/RED_HAWK
cd
cd
cd AllHackingTools
git clone https://github.com/Lulz3xploit/LittleBrother
cd LittleBrother
python3 -m pip install -r requirements.txt
cd
cd
cd AllHackingTools
git clone https://github.com/thewhiteh4t/seeker.git
cd seeker
rm -rf seeker.py 
cd
cd
cd AllHackingTools
cd Castom 
chmod +x seeker.py
cp seeker.py /data/data/com.termux/files/home/
cd
cd
mv seeker.py /data/data/com.termux/files/home/AllHackingTools/seeker/ 
cd
cd
cd AllHackingTools
git clone https://github.com/s0md3v/ReconDog
cd ReconDog
chmod +x dog
cd
cd
cd AllHackingTools
git clone https://github.com/bibortone/D-Tech
cd
cd
cd AllHackingTools
pip install iphack
pip3 install iphack
cd 
cd
cd AllHackingTools
git clone https://github.com/sullo/nikto
cd 
cd
cd AllHackingTools
wget https://raw.githubusercontent.com/crunchsec/ismtp/master/ismtp.py
cd
cd
cd AllHackingTools
git clone https://github.com/mishakorzik/MailFinder
cd
cd
cd AllHackingTools



