echo Zz0iXDAzM1sxOzMybSIKcj0iXDAzM1sxOzMxbSIKYj0iXDAzM1sxOzM0bSIKdz0iXDAzM1swbSIKCmNkCmNkCmNkIEFsbEhhY2tpbmdUb29scwplY2hvIC1lICRiIj4iJHciIHVwZ3JhZGluZyBwYWNrZWdlczogIiRnInBrZyAmIGFwdCIkdwpwa2cgdXBncmFkZQphcHQgdXBncmFkZQplY2hvIC1lICRiIj4iJHciIGluc3RhbGxpbmcgbW9kdWxlczogIiRnInB5dGhvbiIkdwphcHQtZ2V0IGluc3RhbGwgcHl0aG9uCnBrZyBpbnN0YWxsIHB5dGhvbgpwa2cgaW5zdGFsbCBweXRob24yCnBrZyBpbnN0YWxsIHB5dGhvbjMKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJ3Z2V0IiR3CmFwdCBpbnN0YWxsIHdnZXQgCmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGcib3BlbnNzaCIkdwphcHQgaW5zdGFsbCBvcGVuc3NoIAplY2hvIC1lICRiIj4iJHciIGluc3RhbGxpbmcgbW9kdWxlczogIiRnInBocCIkdwphcHQgaW5zdGFsbCBwaHAKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJ0b2lsZXQiJHcKYXB0IGluc3RhbGwgdG9pbGV0CmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGciY29sb3JhbWEiJHcKYXB0IGluc3RhbGwgY29sb3JhbWEKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJqcSIkdwphcHQgaW5zdGFsbCBqcSAKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJhcGFjaGUyIiR3CmFwdCBpbnN0YWxsIGFwYWNoZTIKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJydWJ5IiR3CmFwdCBpbnN0YWxsIHJ1YnkgCmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGciY2xhbmciJHcKYXB0IGluc3RhbGwgY2xhbmcKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJzc2wiJHcKYXB0IGluc3RhbGwgc3NsIC15CmFwdCBpbnN0YWxsIG9wZW5zc2wgLXkKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJ3M20iJHcKYXB0IGluc3RhbGwgdzNtIC15CmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGciZmlnbGV0IiR3CmFwdCBpbnN0YWxsIGZpZ2xldAplY2hvIC1lICRiIj4iJHciIGluc3RhbGxpbmcgbW9kdWxlczogIiRnImxvbGNhdCIkdwpwa2cgaW5zdGFsbCBwaXAKcGtnIGluc3RhbGwgcGlwMgpwaXAyIGluc3RhbGwgLS11cGdyYWRlIHBpcApwaXAgaW5zdGFsbCBsb2xjYXQKZ2VtIGluc3RhbGwgbG9sY2F0CmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGciemlwIiR3CmFwdCBpbnN0YWxsIHppcCAKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJsb2xjYXQiJHcKYXB0IGluc3RhbGwgbG9sY2F0CmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGcicHYiJHcKYXB0IGluc3RhbGwgcHYgCmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGcibmVvZmV0Y2giJHcKYXB0IGluc3RhbGwgbmVvZmV0Y2gKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJ6c2giJHcKYXB0IGluc3RhbGwgenNoCmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGcid2dldCIkdwphcHQgaW5zdGFsbCB3Z2V0CmVjaG8gLWUgJGIiPiIkdyIgaW5zdGFsbGluZyBtb2R1bGVzOiAiJGcibmVvZmV0Y2giJHcKYXB0IGluc3RhbGwgbmVvZmV0Y2gKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJjdXJsIiR3CmFwdCBpbnN0YWxsIGN1cmwKc2xlZXAgMQplY2hvICcK4paI4paI4paI4paI4paI4paI4pWX4paR4paR4paI4paI4paI4paI4paI4pWX4paR4paR4paI4paI4paI4paI4paI4paI4pWX4paI4paI4paI4paI4paI4paI4paI4pWXICAg4paI4paI4pWX4paI4paI4paI4pWX4paR4paR4paI4paI4pWX4paR4paI4paI4paI4paI4paI4paI4pWX4paI4paI4paI4paI4paI4paI4paI4paI4pWX4paR4paI4paI4paI4paI4paI4pWX4paR4paI4paI4pWX4paR4paR4paR4paR4paR4paI4paI4pWX4paR4paR4paR4paR4paR4paI4paI4pWX4paI4paI4paI4pWX4paR4paR4paI4paI4pWX4paR4paI4paI4paI4paI4paI4paI4pWX4paRCuKWiOKWiOKVlOKVkOKVkOKWiOKWiOKVl+KWiOKWiOKVlOKVkOKVkOKWiOKWiOKVl+KWiOKWiOKVlOKVkOKVkOKVkOKVkOKVneKWiOKWiOKVlOKVkOKVkOKVkOKVkOKVnSAgIOKWiOKWiOKVkeKWiOKWiOKWiOKWiOKVl+KWkeKWiOKWiOKVkeKWiOKWiOKVlOKVkOKVkOKVkOKVkOKVneKVmuKVkOKVkOKWiOKWiOKVlOKVkOKVkOKVneKWiOKWiOKVlOKVkOKVkOKWiOKWiOKVl+KWiOKWiOKVkeKWkeKWkeKWkeKWkeKWkeKWiOKWiOKVkeKWkeKWkeKWkeKWkeKWkeKWiOKWiOKVkeKWiOKWiOKWiOKWiOKVl+KWkeKWiOKWiOKVkeKWiOKWiOKVlOKVkOKVkOKVkOKVkOKVneKWkQrilojilojilojilojilojilojilabilZ3ilojilojilojilojilojilojilojilZHilZrilojilojilojilojilojilZfilpHilojilojilojilojilojilZfilpHilpEgICDilojilojilZHilojilojilZTilojilojilZfilojilojilZHilZrilojilojilojilojilojilZfilpHilpHilpHilpHilojilojilZHilpHilpHilpHilojilojilojilojilojilojilojilZHilojilojilZHilpHilpHilpHilpHilpHilojilojilZHilpHilpHilpHilpHilpHilojilojilZHilojilojilZTilojilojilZfilojilojilZHilojilojilZHilpHilpHilojilojilZfilpEK4paI4paI4pWU4pWQ4pWQ4paI4paI4pWX4paI4paI4pWU4pWQ4pWQ4paI4paI4pWR4paR4pWa4pWQ4pWQ4pWQ4paI4paI4pWX4paI4paI4pWU4pWQ4pWQ4pWd4paR4paRICAg4paI4paI4pWR4paI4paI4pWR4pWa4paI4paI4paI4paI4pWR4paR4pWa4pWQ4pWQ4pWQ4paI4paI4pWX4paR4paR4paR4paI4paI4pWR4paR4paR4paR4paI4paI4pWU4pWQ4pWQ4paI4paI4pWR4paI4paI4pWR4paR4paR4paR4paR4paR4paI4paI4pWR4paR4paR4paR4paR4paR4paI4paI4pWR4paI4paI4pWR4pWa4paI4paI4paI4paI4pWR4paI4paI4pWR4paR4paR4pWa4paI4paI4pWXCuKWiOKWiOKWiOKWiOKWiOKWiOKVpuKVneKWiOKWiOKVkeKWkeKWkeKWiOKWiOKVkeKWiOKWiOKWiOKWiOKWiOKWiOKVlOKVneKWiOKWiOKWiOKWiOKWiOKWiOKWiOKVlyAgIOKWiOKWiOKVkeKWiOKWiOKVkeKWkeKVmuKWiOKWiOKWiOKVkeKWiOKWiOKWiOKWiOKWiOKWiOKVlOKVneKWkeKWkeKWkeKWiOKWiOKVkeKWkeKWkeKWkeKWiOKWiOKVkeKWkeKWkeKWiOKWiOKVkeKWiOKWiOKWiOKWiOKWiOKWiOKWiOKVl+KWiOKWiOKWiOKWiOKWiOKWiOKWiOKVl+KWiOKWiOKVkeKWiOKWiOKVkeKWkeKVmuKWiOKWiOKWiOKVkeKVmuKWiOKWiOKWiOKWiOKWiOKWiOKVlOKVnQrilZrilZDilZDilZDilZDilZDilZ3ilpHilZrilZDilZ3ilpHilpHilZrilZDilZ3ilZrilZDilZDilZDilZDilZDilZ3ilpHilZrilZDilZDilZDilZDilZDilZDilZ0gICDilZrilZDilZ3ilZrilZDilZ3ilpHilpHilZrilZDilZDilZ3ilZrilZDilZDilZDilZDilZDilZ3ilpHilpHilpHilpHilZrilZDilZ3ilpHilpHilpHilZrilZDilZ3ilpHilpHilZrilZDilZ3ilZrilZDilZDilZDilZDilZDilZDilZ3ilZrilZDilZDilZDilZDilZDilZDilZ3ilZrilZDilZ3ilZrilZDilZ3ilpHilpHilZrilZDilZDilZ3ilpHilZrilZDilZDilZDilZDilZDilZ3ilpEKJ3xsb2xjYXQgLXAgMS41CnNsZWVwIDIKZWNobyAtZSAkYiI+IiR3IiBpbnN0YWxsaW5nIG1vZHVsZXM6ICIkZyJwaXAiJHcKcGtnIGluc3RhbGwgcGlwMgphcHQgaW5zdGFsbCBweXRob24tZGV2IC15CmFwdCBpbnN0YWxsIHB5dGhvbjMgLXkKYXB0LWdldCBpbnN0YWxsIHBpcDIKcGlwIGluc3RhbGwgLS11cGdyYWRlIHBpcDIKYXB0LWdldCBpbnN0YWxsIHRlcm11eC1hcGkKcGtnIGluc3RhbGwgdGVybXV4LWFwaQpwaXAyIGluc3RhbGwgLS11cGdyYWRlIHBpcApwaXAyIGluc3RhbGwgcGFzc2xpYgpwaXAgaW5zdGFsbCBwYXNzbGliCnBpcDIgaW5zdGFsbCBwcm9ncmVzc2JhcgpwaXAgaW5zdGFsbCBwcm9ncmVzc2JhcgpwaXAyIGluc3RhbGwgZnV0dXJlCnBpcCBpbnN0YWxsIGZ1dHVyZQpwaXAyIGluc3RhbGwgY29sb3JhbWEKcGlwIGluc3RhbGwgZmxhc2sKcGlwMiBpbnN0YWxsIGZsYXNrX3NvY2tldGlvCnBpcCBpbnN0YWxsIGZsYXNrX3NvY2tldGlvCnBpcDMgaW5zdGFsbCBmbGFza19zb2NrZXRpbwpwaXAzIGluc3RhbGwgZmxhc2tfY29ycwpwaXAyIGluc3RhbGwgZmxhc2tfY29ycwpwaXAyIGluc3RhbGwgbWVjaGFuaXplCmNkIApjZCBBbGxIYWNraW5nVG9vbHM= | base64 -d | bash
cd 
cd AllHackingTools
bash Files/CamHackFiles.sh
bash Files/AndroidFiles.sh
bash Files/SocialFiles.sh
bash Files/MailFiles.sh
bash Files/WebFiles.sh
echo ZWNobyAtZSAkdyJbIiRnIklORk8iJHciXSIkYiJMb2FkaW5nIHdhaXQgYSBtb21lbnQiJHcKc2xlZXAgMC4yCmVjaG8gLWUgJHciWyIkbyJXQVJOIiR3Il0iJGIiQSBkb24ndCBjbG9zZSB0ZXJtdXggYXBwISIkdwpzbGVlcCAwLjMKZWNobyAtZSAkdyJbIiRyIkVSUk8iJHciXSIkYiJFcnJvciBpbnN0YWxsaW5nISBSZWxvYWRpbmcgaW5zdGFsbGluZy4iJHcKc2xlZXAgMC4xCmVjaG8gLWUgJHciWyIkZyJJTkZPIiR3Il0iJGIiU3VjY2VzZnVsbCEgTG9hZGluZyBpbnN0YWxsaW5nISIkdwpzbGVlcCAwLjMKZWNobyAtZSAkdyJbIiRvIldBUk4iJHciXSIkYiJTdGFydGluZyBwbGVhc2Ugd2FpdCEiJHcKc2xlZXAgMC4z | base64 -d | bash
bash Files/PhishingFiles.sh
bash Files/RouterFiles.sh
bash Files/SQLinjectionFiles.sh
bash Files/SpamFiles.sh
bash Files/AnalystickFiles.sh
bash Files/WordlistGeneratorFiles.sh
bash Files/XSSAttackFiles.sh
echo '
██╗███╗░░██╗░██████╗████████╗░█████╗░██╗░░░░░██╗░░░░░██╗███╗░░██╗░██████╗░
██║████╗░██║██╔════╝╚══██╔══╝██╔══██╗██║░░░░░██║░░░░░██║████╗░██║██╔════╝░
██║██╔██╗██║╚█████╗░░░░██║░░░███████║██║░░░░░██║░░░░░██║██╔██╗██║██║░░██╗░
██║██║╚████║░╚═══██╗░░░██║░░░██╔══██║██║░░░░░██║░░░░░██║██║╚████║██║░░╚██╗
██║██║░╚███║██████╔╝░░░██║░░░██║░░██║███████╗███████╗██║██║░╚███║╚██████╔╝
╚═╝╚═╝░░╚══╝╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝╚══════╝╚══════╝╚═╝╚═╝░░╚══╝░╚═════╝░
'|lolcat -a -d 8 -s 35.0 -p 1.7
bash Files/PassworldFiles.sh
bash Files/DarkSearchFiles.sh
bash Files/IpFiles.sh
bash Files/TermuxSFiles.sh
bash Files/OtherFiles.sh
cd
cd
cd AllHackingTools
cd Tool
cp msdconsole /data/data/com.termux/files/usr/bin/
cp msdconsoleUPD /data/data/com.termux/files/usr/bin/
cp msdc /data/data/com.termux/files/usr/bin/
cd
cd
cd /data/data/com.termux/files/usr/bin/
chmod +x msdconsole
chmod +x msdconsoleUPD
chmod +x msdc
ls
sleep 0.2
clear
cd 
cd 
pkg upgrade
apt full-upgrade
apt list
sleep 0.4
clear
sleep 0.2
cd
cd
git clone https://github.com/mishakorzik/qiq
cd qiq
bash install.sh
cd
cd
python3 AllHackingTools/.check/ServerStatusCheck.py
cd
cd
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git
echo "source ${(q-)PWD}/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" >> ${ZDOTDIR:-$HOME}/.zshrc
cd
cd
cd AllHackingTools 
cd .fonts
chmod +x *
cp * /data/data/com.termux/files/usr/share/figlet
cd $HOME
cd
cd
bash AllHackingTools/.check/ServerConfig.sh
cd  
cd
cd AllHackingTools
cd Castom
cp ngrok /data/data/com.temux/files/home/
cd
cd
sleep 0.2
echo '
██████╗░░█████╗░███╗░░██╗███████╗
██╔══██╗██╔══██╗████╗░██║██╔════╝
██║░░██║██║░░██║██╔██╗██║█████╗░░
██║░░██║██║░░██║██║╚████║██╔══╝░░
██████╔╝╚█████╔╝██║░╚███║███████╗
╚═════╝░░╚════╝░╚═╝░░╚══╝╚══════╝
Developer : mishakorzhik
created on: 23 05 2021
code      : python, bash
'|lolcat -p 1.0
echo -e $b"[^_^]"$w" SuccesFull Installed: "$g"AllHackingTools"$w
echo -e $b"[^_^]"$w" Run Command to Start Tool: "$g"msdconsole"$w
echo -e $b"[^_^]"$w" Command to Update Tool: "$g"msdconsoleUPD"$w
cd
cd
