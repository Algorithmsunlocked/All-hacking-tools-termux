echo '
   ╔[NOTICE] Steeper Tools
  [01] >> Information Gathering: 
   ├ Collects information from database
   ├ Find More Information
   ├ More Information In User
  [02] >> Exploitation Tools:
   ├ Selection of tools for operation and hacking
   ├ Tools for special operations 
   ├ blackmail utilities And human use
  [SKIP]┐
      ┌[03] >> Sniffing and Spoofing:  -  Tools for forgery of data and databases
      │[04] >> Web Attack Tools:  -  Tools for hacking websites and servers
  [-]─┘[05] >> Cam Hacking Tools:  -  Tools for hacking cams and front camera
       [06] >> Remote Trojan RAT:  -  Utilities for creating RAT virus
      ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣        
   ╔[NOTICE] Useful Tools 
  [07] >> SQL injection Tool:
   ├ Tools for creating viruses
   ├ And cracking devices
  [08] >> SocialMedia Hacking:
   ├ Tools for hacking social networks
   ├ And Bruteforce social networks
  [>]┐
   ┌[SKIP]
  [09] >> Bombing & Spamming Tools:  -  Utilities for sms bombing And Sending Anonymous SMS
  [10] >> Vulnerability Analysis:  -  Systems for vulnerability analysis 
  [11] >> DarkSearch Tools:      -  Tools for search in DarkNet & DeepWeb
  [12] >> Phishing And IpHack:  -  Tools for phishing and fake websites
  [13] >> Passworld Attack:    -  Utilities for cracking passwords
  [14] >> Wordlist Generator:  -  Tools for Genering Worldlist
  [15] >> XSS Attack Tools:  -  Utilities for Attacking XSS
  [16] >> Discord leaks:   - Discord mass users information
  [17] >> Telegram Info: - Mass Telegram users information

      ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣
  [18] >> Other tools: 
   ├ Separate and other tools for hacking
  [19] >> Terminal Panel: 
   ├ Termux control and special features
  [SKIP]┐
      ┌[20] >> System Settings:  -  AllHackingTools control and special features
      │[21] >> System License:  -  View the license in AllHackingTools
  [-]─┘[22] >> Update System:  -  Update system and all tools & menu 
       [23] >> About System:  -  View system information and developer
       [24] >> Exit System:  -  Log out of the AllHackingTools system 
       [25] >> Log Out Terminal  -  Log out in AllHackingTools And Terminal'|lolcat -p 4.6

