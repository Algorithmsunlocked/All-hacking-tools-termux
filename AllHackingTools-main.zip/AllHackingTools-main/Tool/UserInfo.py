
print(f"[\x1b[38;5;9mSYSTEM\x1b[38;5;255m] \x1b[38;5;227mWelcome user! \x1b[38;5;119mWe are glad to see you. \x1b[38;5;227mTo run AllHackingTools, type the command: \x1b[38;5;9mmsdc")
print(f"[\x1b[38;5;9mSYSTEM\x1b[38;5;255m] \x1b[38;5;227mIf AllHackingTools does \x1b[38;5;9mnot work,\x1b[38;5;227m go to: \x1b[38;5;119mgithub.com/mishakorzik/AllHackingTools")
print(f"[\x1b[38;5;9mSYSTEM\x1b[38;5;255m] \x1b[38;5;227mAllHackingTools donate: \x1b[38;5;119mhttps://www.buymeacoffee.com/misakorzik")
